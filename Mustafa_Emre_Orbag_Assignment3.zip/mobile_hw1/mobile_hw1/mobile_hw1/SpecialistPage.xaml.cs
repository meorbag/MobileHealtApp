﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace mobile_hw1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SpecialistPage : ContentPage
    {
        public SpecialistPage()
        {
            InitializeComponent();

            var Specialists = new List<Specialist>
            {
                new Specialist {Name="Metin KORKMAZ", Speciality="Optometrist", Rating="★★★☆☆",ImageUrl="doc1.jpg" },
                new Specialist {Name="Nuri MENTEŞE", Speciality="Internal Diseases", Rating="★★★★☆", ImageUrl="doc2.png"},
                new Specialist {Name="Cansu TOSUN", Speciality="Psychiatry", Rating="★★★★☆",ImageUrl="doc3.png" },
                new Specialist {Name="Kenan YAĞIZ", Speciality="Brain", Rating="★★★★☆", ImageUrl="doc4.jpg" },
                new Specialist {Name="Pelin TOKMAKÇI", Speciality="Podlatrics", Rating="★★★★★",ImageUrl="doc5.png" },
                new Specialist {Name="Hamit TAŞKIRAN", Speciality="Neurology", Rating="★★★★★", ImageUrl="doc6.png" },
                new Specialist {Name="Defne KAYA", Speciality="Physician", Rating="★★★★☆", ImageUrl="profile2.png" }
            };

            SpecialistListView.ItemsSource = Specialists;

        }

        public void Button_Clicked(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            var ob = btn.CommandParameter as Specialist;

            App.Current.MainPage = new welcome(ob.Name, ob.Speciality, ob.Rating, ob.ImageUrl); 


        }
    }
}