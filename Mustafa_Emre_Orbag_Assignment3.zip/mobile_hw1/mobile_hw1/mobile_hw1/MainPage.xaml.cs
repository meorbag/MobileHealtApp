﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mobile_hw1.Tables;
using SQLite;
using Xamarin.Forms;

namespace mobile_hw1
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            lblclick();
        }


        void lblclick()
        {
            label1.GestureRecognizers.Add(new TapGestureRecognizer()
            {
                Command = new Command(() =>
                {
                    App.Current.MainPage = new registerPage();

                })
            });
        }

        public void ShowPass(object sender, EventArgs args)
        {
            Password.IsPassword = Password.IsPassword ? false : true;
        }

        async void Button_Clicked(object sender, EventArgs e)
        {

            var dbpath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "UserDataBase.db");
            var db = new SQLiteConnection(dbpath);
            var myquery = db.Table<RegUserTable>().Where(u => u.UserName.Equals(UName.Text) && u.UserPassword.Equals(Password.Text)).FirstOrDefault();

            if(myquery!=null)
            {
                
                Device.BeginInvokeOnMainThread(async () => {

                    var result = await this.DisplayAlert("Success!", "There is a match! Now being redirected..", null,"GO!");

                    if (!result)
                        App.Current.MainPage = new welcome();
                });
            }
            else
            {
                Device.BeginInvokeOnMainThread(async () => {

                    var result = await this.DisplayAlert("Error", "Username or Password incorrect", "Register", "Try Again");

                    if (result)
                        App.Current.MainPage = new registerPage();
                    else
                    {
                        App.Current.MainPage = new MainPage();
                    }
                });
            }
        }

        async void OnBackPressed(object sender, EventArgs e)
        {
            var result = await this.DisplayAlert("EXIT", "Are you sure to exit the app", "Exit", "Cancel");

            if (result)
                System.Diagnostics.Process.GetCurrentProcess().Kill();
            else
            {
                App.Current.MainPage = new MainPage();
            }
            
        }
    }

}
