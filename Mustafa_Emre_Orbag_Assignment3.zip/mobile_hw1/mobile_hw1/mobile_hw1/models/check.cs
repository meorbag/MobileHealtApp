﻿using System;
using System.Collections.Generic;
using System.Text;

namespace mobile_hw1.models
{
    class check
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public string Details { get; set; }
        public string Details2 { get; set; }
        public string ImageUrl { get; set; }
        public string btn { get; set; }
        public string btnclr { get; set; }

    }
}
