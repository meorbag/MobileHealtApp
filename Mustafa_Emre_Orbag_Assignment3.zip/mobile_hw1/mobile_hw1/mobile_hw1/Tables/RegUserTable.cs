﻿using System;
using System.Collections.Generic;
using System.Text;

namespace mobile_hw1.Tables
{
    public class RegUserTable
    {

        public Guid UserID { get; set; }
        public String UserName { get; set; }
        public String UserPassword { get; set; }

    }
}
