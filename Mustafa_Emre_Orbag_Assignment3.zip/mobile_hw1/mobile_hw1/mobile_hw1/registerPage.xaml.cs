﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mobile_hw1.Tables;
using SQLite;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace mobile_hw1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class registerPage : ContentPage
    {
        public registerPage()
        {
            InitializeComponent();
        }

        private bool IsTableExists(string v)
        {
            string dbpath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "UserDataBase.db");
            var db = new SQLiteConnection(dbpath);
            try
            {
                var tableInfo = db.GetTableInfo("RegUserTable");
                if (tableInfo.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        async void Button_Clicked(object sender, EventArgs e)
        {
            try
            {
                if(UName.Text.Length>0 && UPassword.Text.Length > 0)
                {

                
                    var dbpath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "UserDataBase.db");
                            var db = new SQLiteConnection(dbpath);
                            db.CreateTable<RegUserTable>();

                            if (IsTableExists("RegUserTable") == true)
                            {
                                var regquery = db.Table<RegUserTable>().Where(a => a.UserName == UName.Text).FirstOrDefault();
                                if (regquery != null)
                                {
                                    await App.Current.MainPage.DisplayAlert("Alert", "The User Registered Before, Please use another Username", "OK");
                                }else
                                {
                                    var item = new RegUserTable()
                                    {
                                        UserName = UName.Text,
                                        UserPassword = UPassword.Text
                                    };

                                    db.Insert(item);
                                    Device.BeginInvokeOnMainThread(async () => {

                                        var result = await this.DisplayAlert("Congratulation", "User Registration Sucessful",null ,"OK");

                                        if (!result)
                                            App.Current.MainPage = new MainPage();
                                    });
                                }
                            }
                }
                else
                {
                    Device.BeginInvokeOnMainThread(async () => {

                        var result = await this.DisplayAlert("ALERT", "Username or Password cannot be blank", null, "RETRY");

                        if (!result)
                            App.Current.MainPage = new registerPage();
                    });
                }   
            }
            catch (Exception)
            {
                Device.BeginInvokeOnMainThread(async () => {

                    var result = await this.DisplayAlert("ALERT", "Username or Password cannot be blank", null, "RETRY");

                    if (!result)
                        App.Current.MainPage = new registerPage();
                });
            }

            



        }

        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            App.Current.MainPage = new MainPage();
        }
    }
}