﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using mobile_hw1.models;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;


namespace mobile_hw1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class welcome : Shell
    {
        private string name;
        private string speciality;
        private string rating;
        private string ımageUrl;

        public welcome()
        {
            InitializeComponent();
            Shell.SetNavBarIsVisible(this, false);
            var checks = new List<check>
            {
                new check {Id=1,Name="Doctors", Details="Brain Checkout ",Details2="Have an appointment today", ImageUrl="brain.png", btn="vıew", btnclr="OrangeRed"},
                new check {Id=2,Name="Pharmacy", Details="Purchase Prescription ",Details2="Don't forget to bring the list with you", ImageUrl="tube.png" , btn="set", btnclr="#01C89D"}
            };

            listview1.ItemsSource = checks;
            VisitationClicked();
        }
        public string Name { get; }
        public string Speciality { get; }
        public string ImageUrl { get; }
        public string Rating { get; }

        public welcome(string name, string speciality, string rating, string ımageUrl)
        {


            InitializeComponent();
            Shell.SetNavBarIsVisible(this, false);

            Name = name;
            this.SpecialistName.Text = Name;

            Speciality = speciality;
            this.SpecialistDetail.Text = Speciality;

            ImageUrl = ımageUrl;
            this.SpecialistImg.Source = ImageUrl;

            Rating = rating;
            this.SpecialistRating.Text = Rating;

            var checks = new List<check>
            {
                new check {Id=1,Name="Doctors", Details="Brain Checkout ",Details2="Have an appointment today", ImageUrl="brain.png", btn="vıew", btnclr="OrangeRed"},
                new check {Id=2,Name="Pharmacy", Details="Purchase Prescription ",Details2="Don't forget to bring the list with you", ImageUrl="tube.png" , btn="set", btnclr="#01C89D"}
            };

            listview1.ItemsSource = checks;
            VisitationClicked();

        }

        private void MenuItem_Clicked(object sender, EventArgs e)
        {
            Device.BeginInvokeOnMainThread(async () => {

                var result = await this.DisplayAlert("Logout", "You Are About to Logout", "Logout", "Cancel");

                if (result)
                    App.Current.MainPage = new MainPage();

            });
        }
        async void VisitationClicked()
        {
            Visitation.GestureRecognizers.Add(new TapGestureRecognizer()
            {
                Command = new Command(async () =>
                {
                    await Navigation.PushAsync(new SpecialistPage());

                })
            });
        }
    }
}